/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Estudiantes
 */
public class Cajero {
    private int deposito;
    private int id;
    private int maxDineroDia;

    public int getDeposito() {
        return deposito;
    }

    public void setDeposito(int deposito) {
        this.deposito = deposito;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMaxDineroDia() {
        return maxDineroDia;
    }

    public void setMaxDineroDia(int maxDineroDia) {
        this.maxDineroDia = maxDineroDia;
    }
    
    
}
